import React from 'react';
import './App.css';
import News from './News';

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      searchValue: '',
      displayError: false,
      newsList: []
    };
  }
  handleOnChange = event => {
    this.setState({ searchValue: event.target.value, displayError: false });
  };
  callApi = (searchInput) => {
    const searchUrl = `https://content.guardianapis.com/search?api-key=test&q=${searchInput}&show-fields=thumnail,headline&show-tags=keyword&page=1&page-size=10`;
    fetch(searchUrl)
    .then(response => {
      return response.json();
    })
    .then(jsonData => {
      this.setState({ newsList: jsonData.response && jsonData.response.results });
    })
    .catch(err => console.log(err));
  }
  handleSearch = () => {
    const { searchInput } = this.state;
    this.callApi(searchInput);
  }
  
  render() {
    const { searchValue, displayError, newsList } = this.state;
    return (
      <div>
        <h1>News Lister</h1>
        <div className="main">
          <span className="searchLbl">Enter Search Text</span>
          <input
            name="text"
            type="text"
            placeholder="Search"
            onChange={event => this.handleOnChange(event)}
            value={searchValue}
          />
          <button className="btnSearch" onClick={this.handleSearch}>Search</button> 
          {displayError && 
          <span className="errorLbl">You must enter a search text.</span>
          }
        </div>
        <News data={newsList} />
      </div>
    );
  }
}

export default App;