import React from 'react';
import './App.css';

function News(props) {
  return (
    <div>
      {props.data.length > 0 && <h3>Results</h3>}
      {props.data.map((item) => (
        <div key={item.id} className="newslist">
        <img src="" alt={item.sectionName} className="imgCls" />
        <div className="title"> <p className="headline"> {item.fields.headline} </p>
        {item.tags.slice(0, 3).map((keys) => (
          <span className="keyslist">{keys.webTitle}</span>
        ))}
        </div>
      </div>
      ))}
    </div>
  );
}

export default News;
